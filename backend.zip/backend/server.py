from flask import Flask, request, jsonify
from flask_cors import CORS
import logging
import importlib
from typing import Dict, Type

# Import all connectors
from extractors.connectors.salesforce_connector import SalesforceConnector
from extractors.connectors.google_ads_connector import GoogleAdsConnector
from extractors.connectors.ga4_connector import GA4Connector
from extractors.connectors.meta_ads_connector import MetaAdsConnector
from extractors.connectors.google_sheets_connector import GoogleSheetsConnector
from extractors.base.api_connector import BaseAPIConnector

app = Flask(__name__)
CORS(app)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Connector registry
CONNECTOR_REGISTRY: Dict[str, Type[BaseAPIConnector]] = {
    'salesforce': SalesforceConnector,
    'google_ads': GoogleAdsConnector,
    'ga4': GA4Connector,
    'meta_ads': MetaAdsConnector,
    'google_sheets': GoogleSheetsConnector
}

def get_connector(connector_type: str) -> Type[BaseAPIConnector]:
    """
    Get connector class by type.
    Raises ValueError if connector type not found.
    """
    connector_class = CONNECTOR_REGISTRY.get(connector_type.lower())
    if not connector_class:
        raise ValueError(f"Unsupported connector type: {connector_type}")
    return connector_class

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "available_connectors": list(CONNECTOR_REGISTRY.keys())
    }), 200

@app.route('/api/connectors', methods=['GET'])
def list_connectors():
    """List all available connectors"""
    return jsonify({
        "connectors": list(CONNECTOR_REGISTRY.keys())
    }), 200

@app.route('/api/<connector_type>/connect', methods=['POST'])
def connect(connector_type: str):
    """Generic connection endpoint for any connector"""
    try:
        connector_class = get_connector(connector_type)
        credentials = request.json
        
        # Initialize connector
        connector = connector_class(credentials)
        
        # Attempt authentication
        if connector.authenticate():
            return jsonify({
                "status": "success",
                "message": f"Successfully connected to {connector_type}",
                "connector_info": {
                    "type": connector_type,
                    "authenticated": True
                }
            }), 200
        else:
            return jsonify({
                "status": "error",
                "message": f"Failed to authenticate with {connector_type}"
            }), 401

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error connecting to {connector_type}: {str(e)}")
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/api/<connector_type>/validate', methods=['POST'])
def validate_connection(connector_type: str):
    """Generic validation endpoint for any connector"""
    try:
        connector_class = get_connector(connector_type)
        credentials = request.json
        
        connector = connector_class(credentials)
        if connector.validate_connection():
            return jsonify({
                "status": "success",
                "message": "Connection is valid"
            }), 200
        else:
            return jsonify({
                "status": "error",
                "message": "Connection validation failed"
            }), 401

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error validating {connector_type} connection: {str(e)}")
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/api/<connector_type>/fetch-data', methods=['POST'])
def fetch_data(connector_type: str):
    """Generic data fetching endpoint for any connector"""
    try:
        connector_class = get_connector(connector_type)
        data = request.json
        credentials = data.get('credentials')
        object_name = data.get('object_name')
        query_params = data.get('query_params', {})

        if not all([credentials, object_name]):
            return jsonify({
                "error": "Missing required parameters"
            }), 400

        connector = connector_class(credentials)
        
        # Authenticate first
        if not connector.authenticate():
            return jsonify({
                "error": f"Failed to authenticate with {connector_type}"
            }), 401

        # Fetch data
        records = connector.fetch_data(object_name, query_params)
        
        return jsonify({
            "status": "success",
            "data": records,
            "metadata": {
                "connector_type": connector_type,
                "object_name": object_name,
                "record_count": len(records)
            }
        }), 200

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error fetching data from {connector_type}: {str(e)}")
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/api/<connector_type>/schema', methods=['POST'])
def fetch_schema(connector_type: str):
    """Generic schema fetching endpoint for any connector"""
    try:
        connector_class = get_connector(connector_type)
        data = request.json
        credentials = data.get('credentials')
        object_name = data.get('object_name')

        if not all([credentials, object_name]):
            return jsonify({
                "error": "Missing required parameters"
            }), 400

        connector = connector_class(credentials)
        
        # Authenticate first
        if not connector.authenticate():
            return jsonify({
                "error": f"Failed to authenticate with {connector_type}"
            }), 401

        # Fetch schema
        schema = connector.fetch_schema(object_name)
        
        return jsonify({
            "status": "success",
            "schema": schema,
            "metadata": {
                "connector_type": connector_type,
                "object_name": object_name
            }
        }), 200

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error fetching schema from {connector_type}: {str(e)}")
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

def register_connector(name: str, connector_class: Type[BaseAPIConnector]):
    """
    Dynamically register a new connector at runtime
    """
    CONNECTOR_REGISTRY[name.lower()] = connector_class
    logger.info(f"Registered new connector: {name}")

if __name__ == '__main__':
    # Log available connectors at startup
    logger.info(f"Available connectors: {list(CONNECTOR_REGISTRY.keys())}")
    app.run(host='0.0.0.0', port=5000) 