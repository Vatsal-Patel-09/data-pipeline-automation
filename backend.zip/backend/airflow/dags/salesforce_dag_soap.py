from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.models import Variable
from datetime import datetime
from newutils_salesforce_soap import (
    fetch_and_upload_salesforce_data,
)  # Import the Salesforce function

# default_args = {
#     "owner": "airflow",
#     "depends_on_past": False,
#     "start_date": datetime(2024, 12, 11),
# }

# dag = DAG(
#     "salesforce_to_s3_using_single_variable",
#     default_args=default_args,
#     description="A DAG to fetch Salesforce data and upload to S3",
#     schedule_interval=None,  # Adjust as needed (e.g., '@daily', '0 0 * * *')
# )

# # Retrieve Salesforce configuration from Airflow variable
# salesforce_config = Variable.get("salesforce_dag_var", deserialize_json=True)[0]

# # Unpack object types and file names
# object_types = salesforce_config["object_type"]
# file_names = salesforce_config["file_name"]

# # Ensure object_types and file_names have the same length
# if len(object_types) != len(file_names):
#     raise ValueError("The number of object types and file names must match.")

# # Create a task for each object type and corresponding file name
# tasks = []
# for i, obj_type in enumerate(object_types):
#     task = PythonOperator(
#         task_id=f"fetch_and_upload_{obj_type}_data",  # Valid task_id
#         python_callable=fetch_and_upload_salesforce_data,
#         op_args=[
#             salesforce_config["api_key"],  # API key
#             salesforce_config["instance_url"],  # Salesforce instance URL
#             salesforce_config["bucket_name"],  # S3 bucket name
#             obj_type,  # Current object type
#             file_names[i],  # Corresponding file name
#             salesforce_config["aws_access_key"],  # AWS access key
#             salesforce_config["aws_secret_key"],  # AWS secret key
#         ],
#         dag=dag,
#     )
#     tasks.append(task)

# --------------------------------------------------------------------------------------------------

import os


# Helper function to write DAG code to a file
def write_dag_file(dag_code, filename):
    dag_file_path = os.path.join(dags_folder, filename)
    with open(dag_file_path, "w") as file:
        file.write(dag_code)


# def create_run_dag_code(child_dag_var, schedule, email, env):
#     return f"""
# from airflow import DAG
# from airflow.operators.python import PythonOperator
# from airflow.models import Variable
# from datetime import datetime
# from airflow.utils.dates import days_ago
# from newutils_salesforce_soap import (
#     fetch_and_upload_salesforce_data,
# )  # Import the Salesforce function

# from datetime import datetime

# default_args = {{
#     'owner': 'airflow',
#     'email_on_failure': True,
#     'email': ['{email}'],
#     'email_on_retry': False,
#     "depends_on_past": False,
#     'start_date': days_ago(1),
# }}

# dynamic_var_name = "{child_dag_var}"
# config = Variable.get(dynamic_var_name, deserialize_json=True)
# dag_id = config.get('dag_id') + "_run"
# # sling_api_base_url = Variable.get('SLING_API_URL')

# dag = DAG(
#     dag_id,
#     default_args=default_args,
#     description="A DAG to fetch Salesforce data and upload to S3",
#     schedule_interval='{schedule}',
#     is_paused_upon_creation=True,
#     catchup=False
# )

# # Unpack object types and file names
# object_types = config["object_type"]
# file_names = config["file_name"]

# # Ensure object_types and file_names have the same length
# if len(object_types) != len(file_names):
#     raise ValueError("The number of object types and file names must match.")

# # Create a task for each object type and corresponding file name
# tasks = []
# for i, obj_type in enumerate(object_types):
#     task = PythonOperator(
#         task_id="fetch_and_upload_" + obj_type + "_data",  # Valid task_id
#         python_callable=fetch_and_upload_salesforce_data,
#         op_args=[
#             config["api_key"],  # API key
#             config["instance_url"],  # Salesforce instance URL
#             config["bucket_name"],  # S3 bucket name
#             obj_type,  # Current object type
#             file_names[i],  # Corresponding file name
#             config["aws_access_key"],  # AWS access key
#             config["aws_secret_key"],  # AWS secret key
#         ],
#         dag=dag,
#     )
#     tasks.append(task)
# """

def create_run_dag_code(child_dag_var, schedule, email, env):
    return f"""
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.models import Variable
from datetime import datetime
from airflow.utils.dates import days_ago
from newutils_salesforce_soap import (
    fetch_and_upload_salesforce_data,
)  # Import the Salesforce function

from datetime import datetime

default_args = {{
    'owner': 'airflow',
    'email_on_failure': True,
    'email': ['{email}'],
    'email_on_retry': False,
    "depends_on_past": False,
    'start_date': days_ago(1),
}}

dynamic_var_name = "{child_dag_var}"
config = Variable.get(dynamic_var_name, deserialize_json=True)
dag_id = config.get('dag_id') + "_run"
# sling_api_base_url = Variable.get('SLING_API_URL')

dag = DAG(
    dag_id,
    default_args=default_args,
    description="A DAG to fetch Salesforce data and upload to S3",
    schedule_interval='{schedule}',
    is_paused_upon_creation=True,
    catchup=False
)

source_config = config["source"]
target_config = config["target"]
object_types = source_config["stream"]
file_names = target_config["object"]

# Ensure object_types and file_names have the same length
if len(object_types) != len(file_names):
    raise ValueError("The number of object types and file names must match.")

# Create a task for each object type and corresponding file name
tasks = []
for i, obj_type in enumerate(object_types):
    task = PythonOperator(
        task_id=f"fetch_and_upload_{{obj_type}}_data",
        python_callable=fetch_and_upload_salesforce_data,
        op_args=[
            source_config["details"]["access_token"],  # API key
            source_config["details"]["instance_url"],  # Salesforce instance URL
            target_config["details"]["bucket"],  # S3 bucket name
            obj_type,  # Current object type
            file_names[i],  # Corresponding file name
            target_config["details"]["access_key_id"],  # AWS access key
            target_config["details"]["secret_access_key"],  # AWS secret key
        ],
        dag=dag,
    )
    tasks.append(task)
"""



# # Main DAG creation using the parent DAG function
# salesforce_config = Variable.get("salesforce_dag_var", deserialize_json=True)

# Retrieve the configuration for the dynamic DAGs from Airflow Variables
dag_configs = Variable.get("salesforce_dag_var", deserialize_json=True)

dags_folder = "/opt/airflow/dags/"
default_email = "abhranshu.bagchi@gmail.com"

# Loop through each configuration and generate the appropriate DAGs
for config in dag_configs["dags"]:
    child_dag_var = config["child_dag_var"]
    child_dag_schedule = config["child_dag_schedule"]
    email = config.get("email", default_email)
    dag_type = config.get("dag_type", "ingestion")  # Default to "ingetsion"
    env = os.getenv("ENV", "development")

    # Generate DAGs based on the type
    if dag_type == "ingestion":
        # # Create Setup DAG
        # setup_dag_code = create_setup_dag_code(
        #     child_dag_var, child_dag_schedule, email, env
        # )
        # write_dag_file(setup_dag_code, f"{child_dag_var}_setup.py")

        # Create Run DAG
        run_dag_code = create_run_dag_code(
            child_dag_var, child_dag_schedule, email, env
        )
        write_dag_file(run_dag_code, f"{child_dag_var}_run.py")

    # elif dag_type == "transformation":
    #     # Create a single Transformation DAG
    #     transformation_dag_code = create_transformation_dag_code(
    #         child_dag_var, child_dag_schedule, email
    #     )
    #     write_dag_file(transformation_dag_code, f"{child_dag_var}_transformation.py")

    # elif dag_type == "sql_execution":
    #     sql_execution_dag_code = create_sql_execution_dag_code(
    #         child_dag_var, child_dag_schedule, email
    #     )
    #     write_dag_file(sql_execution_dag_code, f"{child_dag_var}_sql_execution.py")
