import pandas as pd
from simple_salesforce import Salesforce
import boto3
from io import StringIO


def fetch_and_upload_salesforce_data(
    api_key,
    instance_url,
    bucket_name,
    object_type,
    file_name,
    aws_access_key,
    aws_secret_key,
):
    """
    Fetches data from Salesforce for a specific object, converts it to CSV, and uploads it to S3.
    """
    # Create Salesforce instance using the access token
    sf = Salesforce(instance_url=instance_url, session_id=api_key)

    # Describe the object to get all field names
    object_description = getattr(sf, object_type).describe()
    fields = [field["name"] for field in object_description["fields"]]

    # Build the SOQL query dynamically to fetch all fields
    query = f"SELECT {', '.join(fields)} FROM {object_type}"

    # Function to handle pagination and fetch large datasets
    def fetch_all_records(query):
        all_records = []
        try:
            # Initialize the query and fetch the first batch
            results = sf.query(query)

            # Add records from the first batch
            all_records.extend(results["records"])

            # Check if there are more records and paginate if necessary
            while "nextRecordsUrl" in results:
                next_url = results["nextRecordsUrl"]
                results = sf.query_more(next_url, True)
                all_records.extend(results["records"])
                print(f"Fetched {len(results['records'])} records for Lead.")

            return all_records

        except Exception as e:
            print(f"Error while fetching data: {e}")
            return []

    # Fetch all records
    records = fetch_all_records(query)

    if records:
        # Convert the records into a DataFrame
        df = pd.DataFrame(records)

        # Upload to S3
        s3 = boto3.client(
            "s3",
            aws_access_key_id=aws_access_key,
            aws_secret_access_key=aws_secret_key,
        )

        # Convert the DataFrame to CSV
        csv_buffer = StringIO()
        df.to_csv(csv_buffer, index=False)

        # Upload the CSV to S3
        s3.put_object(
            Bucket=bucket_name,
            Key=file_name,
            Body=csv_buffer.getvalue(),
            ContentType="text/csv",
        )

        print(
            f"Uploaded {object_type} data to S3 bucket {bucket_name} with file name {file_name}."
        )
    else:
        print(f"No records found for {object_type}.")
