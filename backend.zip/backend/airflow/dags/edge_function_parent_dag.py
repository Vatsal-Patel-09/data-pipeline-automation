import os
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.utils.dates import days_ago
import boto3
import requests

def create_dag_code(child_dag_var, schedule, email):
    dag_code = f"""
import os
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.utils.dates import days_ago
from airflow.models import Variable
import boto3
import requests

default_args = {{
    'owner': 'airflow',
    'email_on_failure': True,
    'email': ['{email}'],
    'email_on_retry': False,
    'depends_on_past': False,
    'start_date': days_ago(1),
}}

dynamic_var_name = "{child_dag_var}"
config = Variable.get(dynamic_var_name, deserialize_json=True)
dag_id = config.get('dag_id') + "_execution"

dag = DAG(
    dag_id,
    default_args=default_args,
    description='DAG to execute Python code from S3',
    schedule_interval='{schedule}',
    catchup=False,
    tags=["execute-python-dag"],
)

def fetch_python_code_from_s3(s3_url, user_id):
    s3 = boto3.client('s3',
        region_name=Variable.get('AWS_REGION'),
        aws_access_key_id=Variable.get('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=Variable.get('AWS_SECRET_ACCESS_KEY')
    )
    # Assuming the URL is formatted like 'user_id/file_name'
    # user_id, file_name = s3_url.split("/", 1)
    bucket_name = Variable.get('AWS_S3_BUCKET_NAME')
    obj = s3.get_object(Bucket=bucket_name, Key=user_id + "/" + s3_url)
    return obj['Body'].read().decode('utf-8')

def execute_python_code(code):
    url = "http://notebook:8765/execute_python"
    headers = {{"Content-Type": "application/json"}}
    response = requests.post(url, json={{"code": code}}, headers=headers)
    response.raise_for_status()
    return response.json()

def run_python_code(**kwargs):
    s3_url = config['s3_file_url']  # Assume the config contains this key
    user_id = config['user_id']
    python_code = fetch_python_code_from_s3(s3_url, user_id)
    result = execute_python_code(python_code)  # Capture the return value
    print(result)

with dag:
    run_python_code_task = PythonOperator(
        task_id='run_python_code_task',
        python_callable=run_python_code,
        dag=dag
    )
"""
    return dag_code

# Retrieve the configuration for the dynamic DAG from Airflow Variables
dag_configs = Variable.get("parent_edge_function_dag_var", deserialize_json=True)
dags_folder = '/opt/airflow/dags/'
default_email = 'abhranshu.bagchi@gmail.com'

# Generate and write the DAG code for the child DAG configuration
for config in dag_configs['dags']:
    child_dag_var = config['child_dag_var']
    child_dag_schedule = config['child_dag_schedule']

    # Create DAG code
    dag_code = create_dag_code(child_dag_var, child_dag_schedule, default_email)
    dag_file_path = os.path.join(dags_folder, f"{child_dag_var}_execution.py")
    
    with open(dag_file_path, 'w') as file:
        file.write(dag_code)
