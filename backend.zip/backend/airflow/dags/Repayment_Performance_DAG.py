
from airflow import DAG
from airflow.operators.email_operator import EmailOperator
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.utils.decorators import apply_defaults
from airflow.models import Variable
import pytz

IST = pytz.timezone("Asia/Kolkata")

default_args = {
    'owner': 'airflow',
    'email_on_failure': True,
    'email': ['abhranshu.bagchi@gmail.com'],
    'email_on_retry': False,
    'depends_on_past': False,
    'start_date': days_ago(1),
}

class PostgresXComPushOperator(SQLExecuteQueryOperator):

    @apply_defaults
    def __init__(self, *args, **kwargs):
        super(PostgresXComPushOperator, self).__init__(*args, **kwargs)

    def execute(self, context):
        dynamic_var_name = f"Repayment_Performance_DAG"
        config = Variable.get(dynamic_var_name, deserialize_json=True)
        self.sql = config.get('sql')  # Fetch SQL from variable
        self.conn_id = config.get('connection_id')  # Fetch connection ID from variable
        self.log.info("Executing SQL queries")
        hook = PostgresHook(postgres_conn_id=self.conn_id)
        conn = hook.get_conn()
        cursor = conn.cursor()
        try:
            for query in self.sql:
                self.log.info("Executing SQL query: %s", query)
                cursor.execute(query)
                if cursor.description:  # Check if the query returns data
                    result = cursor.fetchall()
                    self.log.info("Query Result: %s", result)
                    result_list = [list(map(lambda x: x.decode('utf-8') if isinstance(x, bytes) else x, row)) for row in result]
                    context['ti'].xcom_push(key='return_value', value=result_list)
                conn.commit()
        except Exception as e:
            self.log.error("Error executing query: %s", e)
            conn.rollback()
            raise
        finally:
            cursor.close()
            conn.close()


dynamic_var_name = f"Repayment_Performance_DAG"
config = Variable.get(dynamic_var_name, deserialize_json=True)
schedule_interval = config.get('schedule_interval', '*/55 * * * *')
dag_id = config.get('dag_id')
sql_queries = config.get('sql')

dag = DAG(
    dag_id,
    default_args=default_args,
    description='A dynamic DAG for Autonmis',
    schedule_interval=schedule_interval,
    default_view="graph",
    catchup=False,
    tags=["dynamic-test-dag"],
)

with dag:
    from_to_date_task = DummyOperator(task_id='start', dag=dag)
    previous_task = from_to_date_task
    for i, sql_query in enumerate(sql_queries):
        run_query = PostgresXComPushOperator(
            task_id=f'dynamic_task_{i}',
            sql=sql_query,  # Fetch SQL directly
            dag=dag
        )
        previous_task >> run_query
        previous_task = run_query

    email_task = EmailOperator(
        task_id='send_email',
        to=["abhranshu.bagchi@gmail.com"],
        subject="Airflow Dynamic DAG Test",
        html_content="DAG execution completed.",
        dag=dag
    )
    previous_task >> email_task

