import os
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.models import Variable
import pytz
from datetime import datetime

IST = pytz.timezone('Asia/Kolkata')

def create_dag_code(child_dag_var, schedule, email, env):
    # Generates the DAG code as a string for a given child DAG configuration
    dag_code = f"""
from airflow import DAG
from airflow.operators.email_operator import EmailOperator
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.utils.decorators import apply_defaults
from airflow.models import Variable
import pytz

IST = pytz.timezone("Asia/Kolkata")

default_args = {{
    'owner': 'airflow',
    'email_on_failure': True,
    'email': ['{email}'],
    'email_on_retry': False,
    'depends_on_past': False,
    'start_date': days_ago(1),
}}

class PostgresXComPushOperator(SQLExecuteQueryOperator):

    @apply_defaults
    def __init__(self, *args, **kwargs):
        super(PostgresXComPushOperator, self).__init__(*args, **kwargs)

    def execute(self, context):
        dynamic_var_name = f"{child_dag_var}"
        config = Variable.get(dynamic_var_name, deserialize_json=True)
        self.sql = config.get('sql')  # Fetch SQL from variable
        self.conn_id = config.get('connection_id')  # Fetch connection ID from variable
        self.log.info("Executing SQL queries")
        hook = PostgresHook(postgres_conn_id=self.conn_id)
        conn = hook.get_conn()
        cursor = conn.cursor()
        try:
            for query in self.sql:
                self.log.info("Executing SQL query: %s", query)
                cursor.execute(query)
                if cursor.description:  # Check if the query returns data
                    result = cursor.fetchall()
                    self.log.info("Query Result: %s", result)
                    result_list = [list(map(lambda x: x.decode('utf-8') if isinstance(x, bytes) else x, row)) for row in result]
                    context['ti'].xcom_push(key='return_value', value=result_list)
                conn.commit()
        except Exception as e:
            self.log.error("Error executing query: %s", e)
            conn.rollback()
            raise
        finally:
            cursor.close()
            conn.close()


dynamic_var_name = f"{child_dag_var}"
config = Variable.get(dynamic_var_name, deserialize_json=True)
schedule_interval = config.get('schedule_interval', '*/55 * * * *')
dag_id = config.get('dag_id')
sql_queries = config.get('sql')

dag = DAG(
    dag_id,
    default_args=default_args,
    description='A dynamic DAG for Autonmis',
    schedule_interval=schedule_interval,
    default_view="graph",
    catchup=False,
    tags=["dynamic-test-dag"],
)

with dag:
    from_to_date_task = DummyOperator(task_id='start', dag=dag)
    previous_task = from_to_date_task
    for i, sql_query in enumerate(sql_queries):
        run_query = PostgresXComPushOperator(
            task_id=f'dynamic_task_{{i}}',
            sql=sql_query,  # Fetch SQL directly
            dag=dag
        )
        previous_task >> run_query
        previous_task = run_query

    email_task = EmailOperator(
        task_id='send_email',
        to=["{email}"],
        subject="Airflow Dynamic DAG Test",
        html_content="DAG execution completed.",
        dag=dag
    )
    previous_task >> email_task

"""
    return dag_code

# Retrieve the configuration for the dynamic DAGs from Airflow Variables
dag_configs = Variable.get("parent_dag_var", deserialize_json=True)
dags_folder = f'/opt/airflow/dags/'
default_email = 'abhranshu.bagchi@gmail.com'
env = os.getenv('ENV', 'development')

# Generate and write the DAG code for each child DAG configuration
for config in dag_configs['dags']:
    child_dag_var = config['child_dag_var']
    child_dag_schedule = config['child_dag_schedule']
    dag_code = create_dag_code(child_dag_var, child_dag_schedule, default_email, env)
    file_path = os.path.join(dags_folder, f"{child_dag_var}.py")
    with open(file_path, 'w') as file:
        file.write(dag_code)
