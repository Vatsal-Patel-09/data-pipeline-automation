"""
HubSpot API connector implementation.
This module provides a connector for Hubspot APIs.
"""